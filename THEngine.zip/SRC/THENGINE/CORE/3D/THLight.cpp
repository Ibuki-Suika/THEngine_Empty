#include "THLight.h"

namespace THEngine
{
	Light::Light()
	{

	}

	Light::~Light()
	{

	}

	/////////////////////////////////////////////////
	DirectionalLight::DirectionalLight()
	{
		type = DIRECTIONAL;
	}

	DirectionalLight::~DirectionalLight()
	{

	}
}