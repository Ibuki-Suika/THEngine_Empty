#include "THCamera.h"

namespace THEngine
{
	void Camera::Update()
	{
		EngineObject::Update();
	}

	void Camera::Draw()
	{

	}

	/////////////////////////////////////////
	Camera2D::Camera2D()
	{

	}

	Camera2D::~Camera2D()
	{

	}

	/////////////////////////////////////////
	Camera3D::Camera3D()
	{

	}

	Camera3D::~Camera3D()
	{

	}
}

