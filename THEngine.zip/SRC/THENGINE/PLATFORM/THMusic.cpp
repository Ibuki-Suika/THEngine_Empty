#include "THMusic.h"

namespace THEngine
{
	Music::Music()
	{

	}

	Music::~Music()
	{

	}


}

